#pragma once
#include <iostream>
using namespace std;

bool getValidInt(int&);
bool getValidFloat(float&);
bool getValidDouble(double&);


