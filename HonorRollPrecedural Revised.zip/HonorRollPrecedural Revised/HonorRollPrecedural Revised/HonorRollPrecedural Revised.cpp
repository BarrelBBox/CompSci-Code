#include <iostream>
#include <algorithm>
#include <cctype>
#include <string>
#include "GetData.h"

using namespace std;
int main()
{
	string firstname;
	string lastname;
	string courseInput;
	int courseAmt;
	int avg = 0;
	int infraction;
	int total = 20;
	int modifiedLength;
	int length;
	double gradeInput = 0;

	//gets names and checks if name contains numbers instead of characters
	cout << "What is your first name?" << endl;
	getline(cin, firstname);
	for (int x = 0; x <= firstname.length(); x++) {
		if (find_if(firstname.begin(), firstname.end(), isdigit) != firstname.end() || firstname.length() < 2) {
			while (find_if(firstname.begin(), firstname.end(), isdigit) != firstname.end() || firstname.length() < 2) {
				cout << "No digits or single characters allowed as or in name, please re-enter. \n";
				getline(cin, firstname);
			}
		}
	}
	cout << "What is your last name?" << endl;
	getline(cin, lastname);
	if (find_if(lastname.begin(), lastname.end(), isdigit) != lastname.end() || lastname.length() < 2) {
		while (find_if(lastname.begin(), lastname.end(), isdigit) != lastname.end() || lastname.length() < 2) {
			cout << "No digits or single characters allowed as or in name, please re-enter. \n";
			getline(cin, lastname);
		}
	}

	string course1;
	string course2;
	string course3;
	string course4;
	string course5;
	string course6;
	string course7;
	string course8;

	int grade1 = 0;
	int grade2 = 0;
	int grade3 = 0;
	int grade4 = 0;
	int grade5 = 0;
	int grade6 = 0;
	int grade7 = 0;
	int grade8 = 0;

	//asks user for course amount and checks if it exceeds the limit or is less than the required minimum
	cout << "How many courses are you taking? ";
	while (!getValidInt(courseAmt)) {
		getValidInt(courseAmt);
	}
	while (courseAmt > 8 || courseAmt < 1) {
		if (courseAmt > 8) {
			while (courseAmt > 8) {
				while (!getValidInt(courseAmt)) {
					cout << "Course amount is less than the required amount, please reduce to a minimum of 1 classes." << endl;
					cout << "Enter course amount: " << endl;
					getValidInt(courseAmt);
				}
			}
		}
		if (courseAmt < 1) {
			while (courseAmt < 1) {
				while (!getValidInt(courseAmt)) {
					cout << "Course amount is less than the required amount, please reduce to a minimum of 1 classes." << endl;
					cout << "Enter course amount: " << endl;
					getValidInt(courseAmt);
				}
			}
		}
	}
	
	//switch to get course names based on amount of courses chosen
	for (int i = 0; i < courseAmt; i++) {
		switch (i) {
		
		case 0:
			cout << "Enter course #1's name" << endl;
			getline(cin, courseInput);
			for (int x = 0; x <= courseInput.length(); x++) {
				if (find_if(courseInput.begin(), courseInput.end(), isdigit) != courseInput.end() || courseInput.length() > 20) {
					while (find_if(courseInput.begin(), courseInput.end(), isdigit) != courseInput.end() || courseInput.length() > 20) {
						cout << "No digits, single characters, or a course name larger than 20 characters is allowed as or in name, please re-enter. \n";
						getline(cin, courseInput);
					}
				}
			}
			course1 = courseInput;
			break;
		case 1:
			cout << "Enter course #2's name" << endl;
			getline(cin, courseInput);
			for (int x = 0; x <= courseInput.length(); x++) {
				if (find_if(courseInput.begin(), courseInput.end(), isdigit) != courseInput.end() || courseInput.length() > 20) {
					while (find_if(courseInput.begin(), courseInput.end(), isdigit) != courseInput.end() || courseInput.length() > 20) {
						cout << "No digits, single characters, or a course name larger than 20 characters is allowed as or in name, please re-enter. \n";
						getline(cin, courseInput);
					}
				}
			}
			course2 = courseInput;
			break;
		case 2:
			cout << "Enter course #3's name" << endl;
			getline(cin, courseInput);
			for (int x = 0; x <= courseInput.length(); x++) {
				if (find_if(courseInput.begin(), courseInput.end(), isdigit) != courseInput.end() || courseInput.length() > 20) {
					while (find_if(courseInput.begin(), courseInput.end(), isdigit) != courseInput.end() || courseInput.length() > 20) {
						cout << "No digits, single characters, or a course name larger than 20 characters is allowed as or in name, please re-enter. \n";
						getline(cin, courseInput);
					}
				}
			}
			course3 = courseInput;
			break;
		case 3:
			cout << "Enter course #4's name" << endl;
			getline(cin, courseInput);
			for (int x = 0; x <= courseInput.length(); x++) {
				if (find_if(courseInput.begin(), courseInput.end(), isdigit) != courseInput.end() || courseInput.length() > 20) {
					while (find_if(courseInput.begin(), courseInput.end(), isdigit) != courseInput.end() || courseInput.length() > 20) {
						cout << "No digits, single characters, or a course name larger than 20 characters is allowed as or in name, please re-enter. \n";
						getline(cin, courseInput);
					}
				}
			}
			course4 = courseInput;
			break;
		case 4:
			cout << "Enter course #5's name" << endl;
			getline(cin, courseInput);
			for (int x = 0; x <= courseInput.length(); x++) {
				if (find_if(courseInput.begin(), courseInput.end(), isdigit) != courseInput.end() || courseInput.length() > 20) {
					while (find_if(courseInput.begin(), courseInput.end(), isdigit) != courseInput.end() || courseInput.length() > 20) {
						cout << "No digits, single characters, or a course name larger than 20 characters is allowed as or in name, please re-enter. \n";
						getline(cin, courseInput);
					}
				}
			}
			course5 = courseInput;
			break;
		case 5:
			cout << "Enter course #6's name" << endl;
			getline(cin, courseInput);
			for (int x = 0; x <= courseInput.length(); x++) {
				if (find_if(courseInput.begin(), courseInput.end(), isdigit) != courseInput.end() || courseInput.length() > 20) {
					while (find_if(courseInput.begin(), courseInput.end(), isdigit) != courseInput.end() || courseInput.length() > 20) {
						cout << "No digits, single characters, or a course name larger than 20 characters is allowed as or in name, please re-enter. \n";
						getline(cin, courseInput);
					}
				}
			}
			course6 = courseInput;
			break;
		case 6:
			cout << "Enter course #7's name" << endl;
			getline(cin, courseInput);
			for (int x = 0; x <= courseInput.length(); x++) {
				if (find_if(courseInput.begin(), courseInput.end(), isdigit) != courseInput.end() || courseInput.length() > 20) {
					while (find_if(courseInput.begin(), courseInput.end(), isdigit) != courseInput.end() || courseInput.length() > 20) {
						cout << "No digits, single characters, or a course name larger than 20 characters is allowed as or in name, please re-enter. \n";
						getline(cin, courseInput);
					}
				}
			}
			course7 = courseInput;
			break;
		case 7:
			cout << "Enter course #8's name" << endl;
			getline(cin, courseInput);
			for (int x = 0; x <= courseInput.length(); x++) {
				if (find_if(courseInput.begin(), courseInput.end(), isdigit) != courseInput.end() || courseInput.length() > 20) {
					while (find_if(courseInput.begin(), courseInput.end(), isdigit) != courseInput.end() || courseInput.length() > 20) {
						cout << "No digits, single characters, or a course name larger than 20 characters is allowed as or in name, please re-enter. \n";
						getline(cin, courseInput);
					}
				}
			}
			course8 = courseInput;
			break;
		}
	}

	//Getting grades from user
	for (int e = 0; e < courseAmt; e++) {
		switch (e) {

		case 0:
			cout << "Enter course #" << (e + 1) << "'s grade" << endl;
			while (!getValidDouble(gradeInput)) {
				getValidDouble(gradeInput);
			}
			while (gradeInput < 0 || gradeInput > 100) {
				if (gradeInput > 100) {
					cout << "Course grade exceeds max limit please restrict it to 100 or less \n";
					while (!getValidDouble(gradeInput)) {
						getValidDouble(gradeInput);
					}
				}
				if (gradeInput < 0) {
					cout << "Course grade exceeds max limit please restrict it to 100 or less \n";
					while (!getValidDouble(gradeInput)) {
						getValidDouble(gradeInput);
					}
				}

			}
			grade1 = round(gradeInput);
			break;
		case 1:
			cout << "Enter course #" << (e + 1) << "'s grade" << endl;
			while (!getValidDouble(gradeInput)) {
				getValidDouble(gradeInput);
			}
			while (gradeInput < 0 || gradeInput > 100) {
				if (gradeInput > 100) {
					cout << "Course grade exceeds max limit please restrict it to 100 or less \n";
					while (!getValidDouble(gradeInput)) {
						getValidDouble(gradeInput);
					}
				}
				if (gradeInput < 0) {
					cout << "Course grade exceeds max limit please restrict it to 100 or less \n";
					while (!getValidDouble(gradeInput)) {
						getValidDouble(gradeInput);
					}
				}

			}
			grade2 = round(gradeInput);
			break;
		case 2:
			cout << "Enter course #" << (e + 1) << "'s grade" << endl;
			while (!getValidDouble(gradeInput)) {
				getValidDouble(gradeInput);
			}
			while (gradeInput < 0 || gradeInput > 100) {
				if (gradeInput > 100) {
					cout << "Course grade exceeds max limit please restrict it to 100 or less \n";
					while (!getValidDouble(gradeInput)) {
						getValidDouble(gradeInput);
					}
				}
				if (gradeInput < 0) {
					cout << "Course grade exceeds max limit please restrict it to 100 or less \n";
					while (!getValidDouble(gradeInput)) {
						getValidDouble(gradeInput);
					}
				}

			}
			grade3 = round(gradeInput);
			break;
		case 3:
			cout << "Enter course #" << (e + 1) << "'s grade" << endl;
			while (!getValidDouble(gradeInput)) {
				getValidDouble(gradeInput);
			}
			while (gradeInput < 0 || gradeInput > 100) {
				if (gradeInput > 100) {
					cout << "Course grade exceeds max limit please restrict it to 100 or less \n";
					while (!getValidDouble(gradeInput)) {
						getValidDouble(gradeInput);
					}
				}
				if (gradeInput < 0) {
					cout << "Course grade exceeds max limit please restrict it to 100 or less \n";
					while (!getValidDouble(gradeInput)) {
						getValidDouble(gradeInput);
					}
				}

			}
			grade4 = round(gradeInput);
			break;
		case 4:
			cout << "Enter course #" << (e + 1) << "'s grade" << endl;
			while (!getValidDouble(gradeInput)) {
				getValidDouble(gradeInput);
			}
			while (gradeInput < 0 || gradeInput > 100) {
				if (gradeInput > 100) {
					cout << "Course grade exceeds max limit please restrict it to 100 or less \n";
					while (!getValidDouble(gradeInput)) {
						getValidDouble(gradeInput);
					}
				}
				if (gradeInput < 0) {
					cout << "Course grade exceeds max limit please restrict it to 100 or less \n";
					while (!getValidDouble(gradeInput)) {
						getValidDouble(gradeInput);
					}
				}

			}
			grade5 = round(gradeInput);
			break;
		case 5:
			cout << "Enter course #" << (e + 1) << "'s grade" << endl;
			while (!getValidDouble(gradeInput)) {
				getValidDouble(gradeInput);
			}
			while (gradeInput < 0 || gradeInput > 100) {
				if (gradeInput > 100) {
					cout << "Course grade exceeds max limit please restrict it to 100 or less \n";
					while (!getValidDouble(gradeInput)) {
						getValidDouble(gradeInput);
					}
				}
				if (gradeInput < 0) {
					cout << "Course grade exceeds max limit please restrict it to 100 or less \n";
					while (!getValidDouble(gradeInput)) {
						getValidDouble(gradeInput);
					}
				}

			}
			grade6 = round(gradeInput);
			break;
		case 6:
			cout << "Enter course #" << (e + 1) << "'s grade" << endl;
			while (!getValidDouble(gradeInput)) {
				getValidDouble(gradeInput);
			}
			while (gradeInput < 0 || gradeInput > 100) {
				if (gradeInput > 100) {
					cout << "Course grade exceeds max limit please restrict it to 100 or less \n";
					while (!getValidDouble(gradeInput)) {
						getValidDouble(gradeInput);
					}
				}
				if (gradeInput < 0) {
					cout << "Course grade exceeds max limit please restrict it to 100 or less \n";
					while (!getValidDouble(gradeInput)) {
						getValidDouble(gradeInput);
					}
				}

			}
			grade7 = round(gradeInput);
			break;
		case 7:
			cout << "Enter course #" << (e + 1) << "'s grade" << endl;
			while (!getValidDouble(gradeInput)) {
				getValidDouble(gradeInput);
			}
			while (gradeInput < 0 || gradeInput > 100) {
				if (gradeInput > 100) {
					cout << "Course grade exceeds max limit please restrict it to 100 or less \n";
					while (!getValidDouble(gradeInput)) {
						getValidDouble(gradeInput);
					}
				}
				if (gradeInput < 0) {
					cout << "Course grade exceeds max limit please restrict it to 100 or less \n";
					while (!getValidDouble(gradeInput)) {
						getValidDouble(gradeInput);
					}
				}

			}
			grade8 = round(gradeInput);
			break;
		}
	}
	
	//grade average
	avg = (grade1 + grade2 + grade3 + grade4 + grade5 + grade6 + grade7 + grade8) / courseAmt;
	avg = round(avg);

	//disciplinary infraction randomizer
	infraction = rand() % 2 + 1;


	//display results
	cout << "Classes          Grades: " << endl;
	for (int f = 0; f < courseAmt; f++) {
		switch (f) {
		case 0:
			length = course1.length();
		    modifiedLength = total - length;
			cout << course1;
			for (int c = 0; c < modifiedLength; c++) {
				cout << " ";
			}
			cout << round(grade1) << endl;
			break;
		case 1:
			length = course2.length();
			modifiedLength = total - length;
			cout << course2;
			for (int c = 0; c < modifiedLength; c++) {
				cout << " ";
			}
			cout << round(grade2) << endl;
			break;
		case 2:
			length = course3.length();
			modifiedLength = total - length;
			cout << course3;
			for (int c = 0; c < modifiedLength; c++) {
				cout << " ";
			}
			cout << round(grade3) << endl;
			break;
		case 3:
			length = course4.length();
			modifiedLength = total - length;
			cout << course4;
			for (int c = 0; c < modifiedLength; c++) {
				cout << " ";
			}
			cout << round(grade4) << endl;
			break;
		case 4:
			length = course5.length();
			modifiedLength = total - length;
			cout << course5;
			for (int c = 0; c < modifiedLength; c++) {
				cout << " ";
			}
			cout << round(grade5) << endl;
			break;
		case 5:
			length = course6.length();
			modifiedLength = total - length;
			cout << course6;
			for (int c = 0; c < modifiedLength; c++) {
				cout << " ";
			}
			cout << round(grade6) << endl;
			break;
		case 6:
			length = course7.length();
			modifiedLength = total - length;
			cout << course7;
			for (int c = 0; c < modifiedLength; c++) {
				cout << " ";
			}
			cout << round(grade7) << endl;
			break;
		case 7:
			length = course8.length();
			modifiedLength = total - length;
			cout << course8;
			for (int c = 0; c < modifiedLength; c++) {
				cout << " ";
			}
			cout << round(grade8) << endl;
			break;
		}
	}

	cout << "Average: " << avg << endl;
	if (infraction = 1) {
		cout << "Infraction: NO" << endl;
	}
	else if (infraction = 2) {
		cout << "Infraction: YES" << endl;
	}

	//honor roll qualifications
	if (infraction < 2 && avg >= 90 && courseAmt >= 5) {
		cout << "Congratulations " << firstname << " " << lastname << "! You have made the honor roll.";
	}
	else {
		cout << "I'm sorry " << firstname << " " << lastname << ", but you didn't qualify for the honor roll.";
	}
}
